import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "./auth";
import { logger } from "../lib/logger";

const router = Router();

// GET /api/users/me
router.get("/me", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  res.json({
    id: user.id,
    clerkId: user.clerkId,
    name: user.name,
    email: user.email,
    mobile: user.mobile ?? null,
    currency: user.currency,
    language: user.language,
    createdAt: user.createdAt.toISOString(),
  });
});

// PUT /api/users/me
router.put("/me", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const { name, mobile, currency, language } = req.body;
  try {
    const [updated] = await db.update(usersTable)
      .set({
        ...(name !== undefined && { name }),
        ...(mobile !== undefined && { mobile }),
        ...(currency !== undefined && { currency }),
        ...(language !== undefined && { language }),
      })
      .where(eq(usersTable.id, user.id))
      .returning();
    res.json({
      id: updated.id,
      clerkId: updated.clerkId,
      name: updated.name,
      email: updated.email,
      mobile: updated.mobile ?? null,
      currency: updated.currency,
      language: updated.language,
      createdAt: updated.createdAt.toISOString(),
    });
  } catch (err) {
    logger.error({ err }, "Failed to update user");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
