import { Router } from "express";
import { db, expensesTable, incomeTable } from "@workspace/db";
import { eq, and, gte, lte, desc, or, ilike } from "drizzle-orm";
import { requireAuth } from "./auth";
import { logger } from "../lib/logger";

const router = Router();

router.get("/", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const { limit = "50", offset = "0", type, from, to, search } = req.query as any;
  const lim = Number(limit);
  const off = Number(offset);

  try {
    const expenseConditions = [eq(expensesTable.userId, user.id)];
    if (from) expenseConditions.push(gte(expensesTable.date, from));
    if (to) expenseConditions.push(lte(expensesTable.date, to));
    if (search) expenseConditions.push(ilike(expensesTable.description, `%${search}%`));

    const incomeConditions = [eq(incomeTable.userId, user.id)];
    if (from) incomeConditions.push(gte(incomeTable.date, from));
    if (to) incomeConditions.push(lte(incomeTable.date, to));
    if (search) incomeConditions.push(ilike(incomeTable.description, `%${search}%`));

    const expenses = type === "income" ? [] : await db.select().from(expensesTable)
      .where(and(...expenseConditions))
      .orderBy(desc(expensesTable.date));

    const incomeRows = type === "expense" ? [] : await db.select().from(incomeTable)
      .where(and(...incomeConditions))
      .orderBy(desc(incomeTable.date));

    const combined = [
      ...expenses.map(e => ({
        id: e.id,
        type: "expense" as const,
        category: e.category,
        amount: Number(e.amount),
        description: e.description ?? null,
        date: e.date,
      })),
      ...incomeRows.map(i => ({
        id: i.id,
        type: "income" as const,
        category: i.source,
        amount: Number(i.amount),
        description: i.description ?? null,
        date: i.date,
      })),
    ].sort((a, b) => b.date.localeCompare(a.date));

    const total = combined.length;
    const items = combined.slice(off, off + lim);

    res.json({ items, total, offset: off, limit: lim });
  } catch (err) {
    logger.error({ err }, "Failed to list transactions");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
