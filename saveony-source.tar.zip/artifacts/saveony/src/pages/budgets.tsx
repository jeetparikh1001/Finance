import { useState } from "react";
import { useListBudgets, useCreateBudget, useUpdateBudget, useDeleteBudget, getListBudgetsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Plus, Pencil, Trash2, Loader2, Target } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

const EXPENSE_CATEGORIES = ["food", "shopping", "travel", "bills", "entertainment", "education", "healthcare", "insurance", "other"];

export function Budgets() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [selectedBudget, setSelectedBudget] = useState<any>(null);

  const { data: budgets, isLoading } = useListBudgets();

  const createMutation = useCreateBudget({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListBudgetsQueryKey() });
        setIsAddOpen(false);
        toast({ title: "Budget created successfully" });
      }
    }
  });

  const updateMutation = useUpdateBudget({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListBudgetsQueryKey() });
        setIsEditOpen(false);
        toast({ title: "Budget updated successfully" });
      }
    }
  });

  const deleteMutation = useDeleteBudget({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListBudgetsQueryKey() });
        toast({ title: "Budget deleted successfully" });
      }
    }
  });

  const handleAddSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createMutation.mutate({
      data: {
        category: formData.get("category") as string,
        limitAmount: Number(formData.get("limitAmount")),
        month: new Date().toISOString().slice(0, 7), // YYYY-MM
      }
    });
  };

  const handleEditSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedBudget) return;
    const formData = new FormData(e.currentTarget);
    updateMutation.mutate({
      id: selectedBudget.id,
      data: {
        category: formData.get("category") as string,
        limitAmount: Number(formData.get("limitAmount")),
      }
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">Budgets</h1>
          <p className="text-slate-400 mt-1">Set limits and track your monthly spending.</p>
        </div>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="bg-violet-600 hover:bg-violet-700 text-white" data-testid="button-create-budget">
              <Plus className="mr-2 h-4 w-4" /> Create Budget
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-900 border-slate-800 text-white">
            <DialogHeader>
              <DialogTitle>Create New Budget</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddSubmit} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select name="category" required defaultValue="food">
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {EXPENSE_CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat} className="capitalize">{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="limitAmount">Monthly Limit</Label>
                <Input id="limitAmount" name="limitAmount" type="number" step="0.01" min="1" required className="bg-slate-800 border-slate-700" placeholder="500.00" />
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createMutation.isPending} className="bg-violet-600 hover:bg-violet-700">
                  {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Save Budget
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex justify-center p-12"><Loader2 className="h-8 w-8 animate-spin text-violet-500" /></div>
      ) : budgets?.length === 0 ? (
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <Target className="h-16 w-16 text-slate-700 mb-4" />
            <h3 className="text-xl font-medium text-white mb-2">No budgets set</h3>
            <p className="text-slate-400 max-w-md">Creating budgets helps you control your spending. Set a limit for a category to start tracking.</p>
            <Button className="mt-6 bg-slate-800 text-white hover:bg-slate-700" onClick={() => setIsAddOpen(true)}>
              Create your first budget
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {budgets?.map((budget) => {
            const percentage = Math.min(100, Math.round((budget.spentAmount / budget.limitAmount) * 100));
            const isOverBudget = percentage >= 100;
            const isWarning = percentage >= 80 && !isOverBudget;
            
            let progressColor = "bg-violet-500";
            if (isOverBudget) progressColor = "bg-rose-500";
            else if (isWarning) progressColor = "bg-amber-500";

            return (
              <Card key={budget.id} className="bg-slate-900 border-slate-800" data-testid={`budget-card-${budget.id}`}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg text-white capitalize">{budget.category}</CardTitle>
                      <CardDescription className="text-slate-400">Monthly Budget</CardDescription>
                    </div>
                    <div className="flex gap-1">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-slate-400 hover:text-white hover:bg-slate-800"
                        onClick={() => {
                          setSelectedBudget(budget);
                          setIsEditOpen(true);
                        }}
                      >
                        <Pencil className="h-3 w-3" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10"
                        onClick={() => {
                          if (confirm("Delete this budget?")) {
                            deleteMutation.mutate({ id: budget.id });
                          }
                        }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-end mb-2">
                    <div>
                      <span className="text-2xl font-bold text-white">${budget.spentAmount.toFixed(0)}</span>
                      <span className="text-slate-400 text-sm ml-1">/ ${budget.limitAmount.toFixed(0)}</span>
                    </div>
                    <span className={`text-sm font-medium ${isOverBudget ? 'text-rose-400' : isWarning ? 'text-amber-400' : 'text-slate-400'}`}>
                      {percentage}%
                    </span>
                  </div>
                  <Progress 
                    value={percentage} 
                    className="h-2 bg-slate-800"
                    indicatorClassName={progressColor}
                  />
                  <div className="mt-4 text-xs text-slate-500 text-right">
                    ${Math.max(0, budget.limitAmount - budget.spentAmount).toFixed(0)} remaining
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white">
          <DialogHeader>
            <DialogTitle>Edit Budget</DialogTitle>
          </DialogHeader>
          {selectedBudget && (
            <form onSubmit={handleEditSubmit} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="edit-category">Category</Label>
                <Select name="category" required defaultValue={selectedBudget.category}>
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {EXPENSE_CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat} className="capitalize">{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-limitAmount">Monthly Limit</Label>
                <Input id="edit-limitAmount" name="limitAmount" type="number" step="0.01" min="1" required defaultValue={selectedBudget.limitAmount} className="bg-slate-800 border-slate-700" />
              </div>
              <DialogFooter>
                <Button type="submit" disabled={updateMutation.isPending} className="bg-violet-600 hover:bg-violet-700">
                  {updateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Update Budget
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
