import { useState } from "react";
import { useListIncome, useCreateIncome, useUpdateIncome, useDeleteIncome, getListIncomeQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { Plus, Search, Pencil, Trash2, Loader2, ArrowDownToLine } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

const INCOME_SOURCES = ["salary", "business", "freelancing", "rental", "investments", "other"];

export function Income() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [selectedIncome, setSelectedIncome] = useState<any>(null);

  const { data: incomeList, isLoading } = useListIncome();

  const createMutation = useCreateIncome({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListIncomeQueryKey() });
        setIsAddOpen(false);
        toast({ title: "Income added successfully" });
      }
    }
  });

  const updateMutation = useUpdateIncome({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListIncomeQueryKey() });
        setIsEditOpen(false);
        toast({ title: "Income updated successfully" });
      }
    }
  });

  const deleteMutation = useDeleteIncome({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListIncomeQueryKey() });
        toast({ title: "Income deleted successfully" });
      }
    }
  });

  const filteredIncome = incomeList?.filter(i => 
    search ? i.description?.toLowerCase().includes(search.toLowerCase()) || i.source.toLowerCase().includes(search.toLowerCase()) : true
  );

  const handleAddSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createMutation.mutate({
      data: {
        source: formData.get("source") as string,
        amount: Number(formData.get("amount")),
        description: formData.get("description") as string,
        date: formData.get("date") as string,
        recurring: formData.get("recurring") === "true",
      }
    });
  };

  const handleEditSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedIncome) return;
    const formData = new FormData(e.currentTarget);
    updateMutation.mutate({
      id: selectedIncome.id,
      data: {
        source: formData.get("source") as string,
        amount: Number(formData.get("amount")),
        description: formData.get("description") as string,
        date: formData.get("date") as string,
        recurring: formData.get("recurring") === "true",
      }
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">Income</h1>
          <p className="text-slate-400 mt-1">Track your earnings and cash flow.</p>
        </div>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" data-testid="button-add-income">
              <Plus className="mr-2 h-4 w-4" /> Add Income
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-900 border-slate-800 text-white">
            <DialogHeader>
              <DialogTitle>Add New Income</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddSubmit} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="source">Source</Label>
                <Select name="source" required defaultValue="salary">
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue placeholder="Select source" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {INCOME_SOURCES.map(src => (
                      <SelectItem key={src} value={src} className="capitalize">{src}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="amount">Amount</Label>
                <Input id="amount" name="amount" type="number" step="0.01" min="0" required className="bg-slate-800 border-slate-700" placeholder="0.00" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Input id="description" name="description" required className="bg-slate-800 border-slate-700" placeholder="Monthly Salary" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input id="date" name="date" type="date" required defaultValue={new Date().toISOString().split('T')[0]} className="bg-slate-800 border-slate-700" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="recurring">Recurring</Label>
                <Select name="recurring" defaultValue="false">
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    <SelectItem value="false">No</SelectItem>
                    <SelectItem value="true">Yes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createMutation.isPending} className="bg-emerald-600 hover:bg-emerald-700">
                  {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Save Income
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader className="flex flex-col sm:flex-row gap-4 justify-between">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
            <Input 
              placeholder="Search income..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 bg-slate-800 border-slate-700 text-white w-full"
              data-testid="input-search-income"
            />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center p-8"><Loader2 className="h-8 w-8 animate-spin text-emerald-500" /></div>
          ) : filteredIncome?.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <ArrowDownToLine className="mx-auto h-12 w-12 text-slate-600 mb-3" />
              <h3 className="text-lg font-medium text-white mb-1">No income found</h3>
              <p>You haven't recorded any income yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-800 hover:bg-slate-800/50">
                    <TableHead className="text-slate-400">Date</TableHead>
                    <TableHead className="text-slate-400">Description</TableHead>
                    <TableHead className="text-slate-400">Source</TableHead>
                    <TableHead className="text-right text-slate-400">Amount</TableHead>
                    <TableHead className="text-right text-slate-400">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredIncome?.map((inc) => (
                    <TableRow key={inc.id} className="border-slate-800 hover:bg-slate-800/50">
                      <TableCell className="text-slate-300 font-medium">
                        {format(new Date(inc.date), 'MMM dd, yyyy')}
                      </TableCell>
                      <TableCell className="text-white">{inc.description}</TableCell>
                      <TableCell>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-800 text-slate-300 capitalize border border-slate-700">
                          {inc.source}
                        </span>
                      </TableCell>
                      <TableCell className="text-right font-bold text-emerald-400">
                        ${inc.amount.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-slate-400 hover:text-white hover:bg-slate-800"
                            onClick={() => {
                              setSelectedIncome(inc);
                              setIsEditOpen(true);
                            }}
                            data-testid={`button-edit-${inc.id}`}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-slate-400 hover:text-rose-400 hover:bg-rose-500/10"
                            onClick={() => {
                              if (confirm("Are you sure you want to delete this income?")) {
                                deleteMutation.mutate({ id: inc.id });
                              }
                            }}
                            data-testid={`button-delete-${inc.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white">
          <DialogHeader>
            <DialogTitle>Edit Income</DialogTitle>
          </DialogHeader>
          {selectedIncome && (
            <form onSubmit={handleEditSubmit} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="edit-source">Source</Label>
                <Select name="source" required defaultValue={selectedIncome.source}>
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue placeholder="Select source" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {INCOME_SOURCES.map(src => (
                      <SelectItem key={src} value={src} className="capitalize">{src}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-amount">Amount</Label>
                <Input id="edit-amount" name="amount" type="number" step="0.01" min="0" required defaultValue={selectedIncome.amount} className="bg-slate-800 border-slate-700" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-description">Description</Label>
                <Input id="edit-description" name="description" required defaultValue={selectedIncome.description} className="bg-slate-800 border-slate-700" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-date">Date</Label>
                <Input id="edit-date" name="date" type="date" required defaultValue={selectedIncome.date.split('T')[0]} className="bg-slate-800 border-slate-700" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-recurring">Recurring</Label>
                <Select name="recurring" defaultValue={selectedIncome.recurring ? "true" : "false"}>
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    <SelectItem value="false">No</SelectItem>
                    <SelectItem value="true">Yes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={updateMutation.isPending} className="bg-emerald-600 hover:bg-emerald-700">
                  {updateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Update Income
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
