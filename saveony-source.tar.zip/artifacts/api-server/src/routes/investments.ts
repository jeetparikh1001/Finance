import { Router } from "express";
import { db, investmentsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth } from "./auth";
import { logger } from "../lib/logger";

const router = Router();

router.get("/", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  try {
    const rows = await db.select().from(investmentsTable).where(eq(investmentsTable.userId, user.id));
    res.json(rows.map(r => ({
      ...r,
      purchasePrice: Number(r.purchasePrice),
      currentPrice: Number(r.currentPrice),
      quantity: Number(r.quantity),
      createdAt: r.createdAt.toISOString(),
    })));
  } catch (err) {
    logger.error({ err }, "Failed to list investments");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const { name, assetType, purchasePrice, currentPrice, quantity, purchaseDate } = req.body;
  if (!name || !assetType || !purchasePrice || !currentPrice || !quantity || !purchaseDate) {
    return res.status(400).json({ error: "All fields required" });
  }
  try {
    const [row] = await db.insert(investmentsTable).values({
      userId: user.id,
      name,
      assetType,
      purchasePrice: String(purchasePrice),
      currentPrice: String(currentPrice),
      quantity: String(quantity),
      purchaseDate,
    }).returning();
    res.status(201).json({ ...row, purchasePrice: Number(row.purchasePrice), currentPrice: Number(row.currentPrice), quantity: Number(row.quantity), createdAt: row.createdAt.toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to create investment");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  const { name, assetType, currentPrice, quantity } = req.body;
  try {
    const [row] = await db.update(investmentsTable)
      .set({
        ...(name !== undefined && { name }),
        ...(assetType !== undefined && { assetType }),
        ...(currentPrice !== undefined && { currentPrice: String(currentPrice) }),
        ...(quantity !== undefined && { quantity: String(quantity) }),
      })
      .where(and(eq(investmentsTable.id, id), eq(investmentsTable.userId, user.id)))
      .returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json({ ...row, purchasePrice: Number(row.purchasePrice), currentPrice: Number(row.currentPrice), quantity: Number(row.quantity), createdAt: row.createdAt.toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to update investment");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  try {
    await db.delete(investmentsTable).where(and(eq(investmentsTable.id, id), eq(investmentsTable.userId, user.id)));
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "Failed to delete investment");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
