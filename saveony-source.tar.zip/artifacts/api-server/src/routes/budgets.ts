import { Router } from "express";
import { db, budgetsTable, expensesTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { requireAuth } from "./auth";
import { logger } from "../lib/logger";

const router = Router();

router.get("/", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  try {
    const rows = await db.select().from(budgetsTable)
      .where(eq(budgetsTable.userId, user.id))
      .orderBy(budgetsTable.month);

    // For each budget, compute actual spent from expenses table
    const enriched = await Promise.all(rows.map(async (b) => {
      const [{ total }] = await db
        .select({ total: sql<string>`coalesce(sum(${expensesTable.amount}), 0)` })
        .from(expensesTable)
        .where(
          and(
            eq(expensesTable.userId, user.id),
            eq(expensesTable.category, b.category),
            sql`to_char(${expensesTable.date}::date, 'YYYY-MM') = ${b.month}`,
          )
        );
      return {
        ...b,
        limitAmount: Number(b.limitAmount),
        spentAmount: Number(total),
        createdAt: b.createdAt.toISOString(),
      };
    }));

    res.json(enriched);
  } catch (err) {
    logger.error({ err }, "Failed to list budgets");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const { category, limitAmount, month } = req.body;
  if (!category || !limitAmount || !month) {
    return res.status(400).json({ error: "category, limitAmount, and month are required" });
  }
  try {
    const [row] = await db.insert(budgetsTable).values({
      userId: user.id,
      category,
      limitAmount: String(limitAmount),
      month,
    }).returning();
    res.status(201).json({ ...row, limitAmount: Number(row.limitAmount), spentAmount: 0, createdAt: row.createdAt.toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to create budget");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  const { category, limitAmount, month } = req.body;
  try {
    const [row] = await db.update(budgetsTable)
      .set({
        ...(category !== undefined && { category }),
        ...(limitAmount !== undefined && { limitAmount: String(limitAmount) }),
        ...(month !== undefined && { month }),
      })
      .where(and(eq(budgetsTable.id, id), eq(budgetsTable.userId, user.id)))
      .returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json({ ...row, limitAmount: Number(row.limitAmount), spentAmount: Number(row.spentAmount), createdAt: row.createdAt.toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to update budget");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  try {
    await db.delete(budgetsTable).where(and(eq(budgetsTable.id, id), eq(budgetsTable.userId, user.id)));
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "Failed to delete budget");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
