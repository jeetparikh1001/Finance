import { Router } from "express";
import { db, incomeTable } from "@workspace/db";
import { eq, and, gte, lte, desc } from "drizzle-orm";
import { requireAuth } from "./auth";
import { logger } from "../lib/logger";

const router = Router();

router.get("/", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const { limit = "50", offset = "0", from, to } = req.query as any;
  try {
    const conditions = [eq(incomeTable.userId, user.id)];
    if (from) conditions.push(gte(incomeTable.date, from));
    if (to) conditions.push(lte(incomeTable.date, to));

    const rows = await db.select().from(incomeTable)
      .where(and(...conditions))
      .orderBy(desc(incomeTable.date))
      .limit(Number(limit))
      .offset(Number(offset));

    res.json(rows.map(r => ({ ...r, amount: Number(r.amount), createdAt: r.createdAt.toISOString() })));
  } catch (err) {
    logger.error({ err }, "Failed to list income");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const { source, amount, description, date, recurring = false } = req.body;
  if (!source || !amount || !date) {
    return res.status(400).json({ error: "source, amount, and date are required" });
  }
  try {
    const [row] = await db.insert(incomeTable).values({
      userId: user.id,
      source,
      amount: String(amount),
      description: description ?? null,
      date,
      recurring,
    }).returning();
    res.status(201).json({ ...row, amount: Number(row.amount), createdAt: row.createdAt.toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to create income");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  const { source, amount, description, date, recurring } = req.body;
  try {
    const [row] = await db.update(incomeTable)
      .set({
        ...(source !== undefined && { source }),
        ...(amount !== undefined && { amount: String(amount) }),
        ...(description !== undefined && { description }),
        ...(date !== undefined && { date }),
        ...(recurring !== undefined && { recurring }),
      })
      .where(and(eq(incomeTable.id, id), eq(incomeTable.userId, user.id)))
      .returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json({ ...row, amount: Number(row.amount), createdAt: row.createdAt.toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to update income");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  try {
    await db.delete(incomeTable).where(and(eq(incomeTable.id, id), eq(incomeTable.userId, user.id)));
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "Failed to delete income");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
