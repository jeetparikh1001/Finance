import { Router } from "express";
import { db, expensesTable, incomeTable, investmentsTable, goalsTable } from "@workspace/db";
import { eq, and, gte, lte, sql } from "drizzle-orm";
import { requireAuth } from "./auth";
import { logger } from "../lib/logger";

const router = Router();

// GET /api/analytics/summary
router.get("/summary", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const now = new Date();
  const monthStart = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`;
  const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const monthEnd = `${nextMonth.getFullYear()}-${String(nextMonth.getMonth() + 1).padStart(2, "0")}-01`;

  try {
    const [{ totalExpenses }] = await db
      .select({ totalExpenses: sql<string>`coalesce(sum(${expensesTable.amount}), 0)` })
      .from(expensesTable)
      .where(and(eq(expensesTable.userId, user.id), gte(expensesTable.date, monthStart), sql`${expensesTable.date} < ${monthEnd}`));

    const [{ totalIncome }] = await db
      .select({ totalIncome: sql<string>`coalesce(sum(${incomeTable.amount}), 0)` })
      .from(incomeTable)
      .where(and(eq(incomeTable.userId, user.id), gte(incomeTable.date, monthStart), sql`${incomeTable.date} < ${monthEnd}`));

    const [{ totalInvested }] = await db
      .select({ totalInvested: sql<string>`coalesce(sum(${investmentsTable.currentPrice} * ${investmentsTable.quantity}), 0)` })
      .from(investmentsTable)
      .where(eq(investmentsTable.userId, user.id));

    const [{ totalSaved }] = await db
      .select({ totalSaved: sql<string>`coalesce(sum(${goalsTable.savedAmount}), 0)` })
      .from(goalsTable)
      .where(eq(goalsTable.userId, user.id));

    const monthlyIncome = Number(totalIncome);
    const monthlyExpenses = Number(totalExpenses);
    const monthlySavings = Math.max(0, monthlyIncome - monthlyExpenses);
    const totalInvestments = Number(totalInvested);
    const savingsPool = Number(totalSaved);
    const totalBalance = monthlySavings + savingsPool;
    const netWorth = totalBalance + totalInvestments;
    const savingsRate = monthlyIncome > 0 ? (monthlySavings / monthlyIncome) * 100 : 0;

    res.json({
      totalBalance,
      monthlyIncome,
      monthlyExpenses,
      monthlySavings,
      totalInvestments,
      netWorth,
      savingsRate: Math.round(savingsRate * 10) / 10,
    });
  } catch (err) {
    logger.error({ err }, "Failed to get summary");
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/analytics/expense-by-category
router.get("/expense-by-category", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const { from, to } = req.query as any;
  try {
    const conditions = [eq(expensesTable.userId, user.id)];
    if (from) conditions.push(gte(expensesTable.date, from));
    if (to) conditions.push(lte(expensesTable.date, to));

    const rows = await db
      .select({
        category: expensesTable.category,
        total: sql<string>`sum(${expensesTable.amount})`,
        count: sql<string>`count(*)`,
      })
      .from(expensesTable)
      .where(and(...conditions))
      .groupBy(expensesTable.category);

    const grandTotal = rows.reduce((s, r) => s + Number(r.total), 0);
    res.json(rows.map(r => ({
      category: r.category,
      total: Number(r.total),
      count: Number(r.count),
      percentage: grandTotal > 0 ? Math.round((Number(r.total) / grandTotal) * 1000) / 10 : 0,
    })));
  } catch (err) {
    logger.error({ err }, "Failed to get expense by category");
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/analytics/income-by-source
router.get("/income-by-source", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const { from, to } = req.query as any;
  try {
    const conditions = [eq(incomeTable.userId, user.id)];
    if (from) conditions.push(gte(incomeTable.date, from));
    if (to) conditions.push(lte(incomeTable.date, to));

    const rows = await db
      .select({
        source: incomeTable.source,
        total: sql<string>`sum(${incomeTable.amount})`,
      })
      .from(incomeTable)
      .where(and(...conditions))
      .groupBy(incomeTable.source);

    const grandTotal = rows.reduce((s, r) => s + Number(r.total), 0);
    res.json(rows.map(r => ({
      source: r.source,
      total: Number(r.total),
      percentage: grandTotal > 0 ? Math.round((Number(r.total) / grandTotal) * 1000) / 10 : 0,
    })));
  } catch (err) {
    logger.error({ err }, "Failed to get income by source");
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/analytics/monthly-trend
router.get("/monthly-trend", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  try {
    const expenseRows = await db
      .select({
        month: sql<string>`to_char(${expensesTable.date}::date, 'YYYY-MM')`,
        total: sql<string>`sum(${expensesTable.amount})`,
      })
      .from(expensesTable)
      .where(and(
        eq(expensesTable.userId, user.id),
        sql`${expensesTable.date}::date >= (current_date - interval '12 months')`,
      ))
      .groupBy(sql`to_char(${expensesTable.date}::date, 'YYYY-MM')`)
      .orderBy(sql`to_char(${expensesTable.date}::date, 'YYYY-MM')`);

    const incomeRows = await db
      .select({
        month: sql<string>`to_char(${incomeTable.date}::date, 'YYYY-MM')`,
        total: sql<string>`sum(${incomeTable.amount})`,
      })
      .from(incomeTable)
      .where(and(
        eq(incomeTable.userId, user.id),
        sql`${incomeTable.date}::date >= (current_date - interval '12 months')`,
      ))
      .groupBy(sql`to_char(${incomeTable.date}::date, 'YYYY-MM')`)
      .orderBy(sql`to_char(${incomeTable.date}::date, 'YYYY-MM')`);

    const months = new Set([
      ...expenseRows.map(r => r.month),
      ...incomeRows.map(r => r.month),
    ]);

    const expenseMap = Object.fromEntries(expenseRows.map(r => [r.month, Number(r.total)]));
    const incomeMap = Object.fromEntries(incomeRows.map(r => [r.month, Number(r.total)]));

    const result = Array.from(months).sort().map(month => {
      const income = incomeMap[month] ?? 0;
      const expenses = expenseMap[month] ?? 0;
      return { month, income, expenses, savings: Math.max(0, income - expenses) };
    });

    res.json(result);
  } catch (err) {
    logger.error({ err }, "Failed to get monthly trend");
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/analytics/net-worth
router.get("/net-worth", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  try {
    const [{ totalInvested }] = await db
      .select({ totalInvested: sql<string>`coalesce(sum(${investmentsTable.currentPrice} * ${investmentsTable.quantity}), 0)` })
      .from(investmentsTable)
      .where(eq(investmentsTable.userId, user.id));

    const [{ totalSaved }] = await db
      .select({ totalSaved: sql<string>`coalesce(sum(${goalsTable.savedAmount}), 0)` })
      .from(goalsTable)
      .where(eq(goalsTable.userId, user.id));

    const investmentValue = Number(totalInvested);
    const savingsValue = Number(totalSaved);
    const totalAssets = investmentValue + savingsValue;
    const totalLiabilities = 0;
    const netWorth = totalAssets - totalLiabilities;

    res.json({ totalAssets, totalLiabilities, netWorth, investmentValue, savingsValue });
  } catch (err) {
    logger.error({ err }, "Failed to get net worth");
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/analytics/recurring — detect recurring patterns
router.get("/recurring", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  try {
    // Look at 6 months of data
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    const fromDate = sixMonthsAgo.toISOString().slice(0, 10);

    const expenses = await db
      .select({
        description: expensesTable.description,
        category: expensesTable.category,
        amount: expensesTable.amount,
        date: expensesTable.date,
      })
      .from(expensesTable)
      .where(and(
        eq(expensesTable.userId, user.id),
        sql`${expensesTable.date}::date >= ${fromDate}::date`,
      ));

    const incomeRows = await db
      .select({
        description: incomeTable.description,
        source: incomeTable.source,
        amount: incomeTable.amount,
        date: incomeTable.date,
      })
      .from(incomeTable)
      .where(and(
        eq(incomeTable.userId, user.id),
        sql`${incomeTable.date}::date >= ${fromDate}::date`,
      ));

    // Group expenses by (description, amount) key
    const expenseGroups = new Map<string, { description: string; category: string; amount: number; months: Set<string>; dates: string[] }>();
    for (const e of expenses) {
      const desc = (e.description ?? "").toLowerCase().trim();
      const amt = Number(e.amount);
      const key = `${desc}|${amt.toFixed(2)}`;
      const month = e.date.slice(0, 7);
      if (!expenseGroups.has(key)) {
        expenseGroups.set(key, { description: e.description ?? desc, category: e.category, amount: amt, months: new Set(), dates: [] });
      }
      const g = expenseGroups.get(key)!;
      g.months.add(month);
      g.dates.push(e.date);
    }

    // Group income by (description, source, amount)
    const incomeGroups = new Map<string, { description: string; category: string; amount: number; months: Set<string>; dates: string[] }>();
    for (const i of incomeRows) {
      const desc = (i.description ?? i.source).toLowerCase().trim();
      const amt = Number(i.amount);
      const key = `${desc}|${amt.toFixed(2)}`;
      const month = i.date.slice(0, 7);
      if (!incomeGroups.has(key)) {
        incomeGroups.set(key, { description: i.description ?? i.source, category: i.source, amount: amt, months: new Set(), dates: [] });
      }
      const g = incomeGroups.get(key)!;
      g.months.add(month);
      g.dates.push(i.date);
    }

    const toRecurringItem = (key: string, g: { description: string; category: string; amount: number; months: Set<string>; dates: string[] }, type: "expense" | "income") => ({
      key,
      description: g.description,
      category: g.category,
      amount: g.amount,
      type,
      monthsDetected: g.months.size,
      confidence: g.months.size >= 3 ? ("confirmed" as const) : ("likely" as const),
      lastSeen: [...g.dates].sort().reverse()[0],
      totalSpent: g.amount * g.months.size,
    });

    const recurringExpenses = [...expenseGroups.entries()]
      .filter(([, g]) => g.months.size >= 2)
      .map(([key, g]) => toRecurringItem(key, g, "expense"))
      .sort((a, b) => b.amount - a.amount);

    const recurringIncome = [...incomeGroups.entries()]
      .filter(([, g]) => g.months.size >= 2)
      .map(([key, g]) => toRecurringItem(key, g, "income"))
      .sort((a, b) => b.amount - a.amount);

    const totalMonthlyRecurringCost = recurringExpenses.reduce((s, r) => s + r.amount, 0);
    const totalMonthlyRecurringIncome = recurringIncome.reduce((s, r) => s + r.amount, 0);

    res.json({
      recurringExpenses,
      recurringIncome,
      totalMonthlyRecurringCost,
      totalMonthlyRecurringIncome,
      detectedAt: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, "Failed to detect recurring transactions");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
