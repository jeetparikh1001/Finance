import { Router } from "express";
import { db, expensesTable } from "@workspace/db";
import { eq, and, gte, lte, desc } from "drizzle-orm";
import { requireAuth } from "./auth";
import { logger } from "../lib/logger";

const router = Router();

router.get("/", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const { limit = "50", offset = "0", category, from, to } = req.query as any;
  try {
    const conditions = [eq(expensesTable.userId, user.id)];
    if (category) conditions.push(eq(expensesTable.category, category));
    if (from) conditions.push(gte(expensesTable.date, from));
    if (to) conditions.push(lte(expensesTable.date, to));

    const rows = await db.select().from(expensesTable)
      .where(and(...conditions))
      .orderBy(desc(expensesTable.date))
      .limit(Number(limit))
      .offset(Number(offset));

    res.json(rows.map(r => ({
      ...r,
      amount: Number(r.amount),
      createdAt: r.createdAt.toISOString(),
    })));
  } catch (err) {
    logger.error({ err }, "Failed to list expenses");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const { category, amount, description, date, recurring = false } = req.body;
  if (!category || !amount || !date) {
    return res.status(400).json({ error: "category, amount, and date are required" });
  }
  try {
    const [row] = await db.insert(expensesTable).values({
      userId: user.id,
      category,
      amount: String(amount),
      description: description ?? null,
      date,
      recurring,
    }).returning();
    res.status(201).json({ ...row, amount: Number(row.amount), createdAt: row.createdAt.toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to create expense");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  try {
    const [row] = await db.select().from(expensesTable)
      .where(and(eq(expensesTable.id, id), eq(expensesTable.userId, user.id)));
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json({ ...row, amount: Number(row.amount), createdAt: row.createdAt.toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to get expense");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  const { category, amount, description, date, recurring } = req.body;
  try {
    const [row] = await db.update(expensesTable)
      .set({
        ...(category !== undefined && { category }),
        ...(amount !== undefined && { amount: String(amount) }),
        ...(description !== undefined && { description }),
        ...(date !== undefined && { date }),
        ...(recurring !== undefined && { recurring }),
      })
      .where(and(eq(expensesTable.id, id), eq(expensesTable.userId, user.id)))
      .returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json({ ...row, amount: Number(row.amount), createdAt: row.createdAt.toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to update expense");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  try {
    await db.delete(expensesTable)
      .where(and(eq(expensesTable.id, id), eq(expensesTable.userId, user.id)));
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "Failed to delete expense");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
