import { Router } from "express";
import { db, goalsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth } from "./auth";
import { logger } from "../lib/logger";

const router = Router();

router.get("/", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  try {
    const rows = await db.select().from(goalsTable).where(eq(goalsTable.userId, user.id));
    res.json(rows.map(r => ({
      ...r,
      targetAmount: Number(r.targetAmount),
      savedAmount: Number(r.savedAmount),
      deadline: r.deadline ?? null,
      createdAt: r.createdAt.toISOString(),
    })));
  } catch (err) {
    logger.error({ err }, "Failed to list goals");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const { name, targetAmount, savedAmount = 0, deadline, type } = req.body;
  if (!name || !targetAmount || !type) {
    return res.status(400).json({ error: "name, targetAmount, and type are required" });
  }
  try {
    const [row] = await db.insert(goalsTable).values({
      userId: user.id,
      name,
      type,
      targetAmount: String(targetAmount),
      savedAmount: String(savedAmount),
      deadline: deadline ?? null,
    }).returning();
    res.status(201).json({ ...row, targetAmount: Number(row.targetAmount), savedAmount: Number(row.savedAmount), deadline: row.deadline ?? null, createdAt: row.createdAt.toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to create goal");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  const { name, targetAmount, savedAmount, deadline, type } = req.body;
  try {
    const [row] = await db.update(goalsTable)
      .set({
        ...(name !== undefined && { name }),
        ...(type !== undefined && { type }),
        ...(targetAmount !== undefined && { targetAmount: String(targetAmount) }),
        ...(savedAmount !== undefined && { savedAmount: String(savedAmount) }),
        ...(deadline !== undefined && { deadline }),
      })
      .where(and(eq(goalsTable.id, id), eq(goalsTable.userId, user.id)))
      .returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json({ ...row, targetAmount: Number(row.targetAmount), savedAmount: Number(row.savedAmount), deadline: row.deadline ?? null, createdAt: row.createdAt.toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to update goal");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  try {
    await db.delete(goalsTable).where(and(eq(goalsTable.id, id), eq(goalsTable.userId, user.id)));
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "Failed to delete goal");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
