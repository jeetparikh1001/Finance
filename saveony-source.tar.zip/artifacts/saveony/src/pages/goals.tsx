import { useState } from "react";
import { useListGoals, useCreateGoal, useUpdateGoal, useDeleteGoal, getListGoalsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Plus, Pencil, Trash2, Loader2, Target, Trophy } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

const GOAL_TYPES = ["emergency", "house", "car", "education", "retirement", "vacation", "custom"];

export function Goals() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState<any>(null);

  const { data: goals, isLoading } = useListGoals();

  const createMutation = useCreateGoal({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListGoalsQueryKey() });
        setIsAddOpen(false);
        toast({ title: "Goal created successfully" });
      }
    }
  });

  const updateMutation = useUpdateGoal({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListGoalsQueryKey() });
        setIsEditOpen(false);
        toast({ title: "Goal updated successfully" });
      }
    }
  });

  const deleteMutation = useDeleteGoal({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListGoalsQueryKey() });
        toast({ title: "Goal deleted successfully" });
      }
    }
  });

  const handleAddSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createMutation.mutate({
      data: {
        name: formData.get("name") as string,
        type: formData.get("type") as string,
        targetAmount: Number(formData.get("targetAmount")),
        savedAmount: Number(formData.get("savedAmount")) || 0,
        deadline: formData.get("deadline") as string || undefined,
      }
    });
  };

  const handleEditSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedGoal) return;
    const formData = new FormData(e.currentTarget);
    updateMutation.mutate({
      id: selectedGoal.id,
      data: {
        name: formData.get("name") as string,
        type: formData.get("type") as string,
        targetAmount: Number(formData.get("targetAmount")),
        savedAmount: Number(formData.get("savedAmount")),
        deadline: formData.get("deadline") as string || undefined,
      }
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">Savings Goals</h1>
          <p className="text-slate-400 mt-1">Set targets and track your progress.</p>
        </div>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="bg-cyan-600 hover:bg-cyan-700 text-white" data-testid="button-create-goal">
              <Plus className="mr-2 h-4 w-4" /> Create Goal
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-900 border-slate-800 text-white">
            <DialogHeader>
              <DialogTitle>Create New Goal</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddSubmit} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="name">Goal Name</Label>
                <Input id="name" name="name" required className="bg-slate-800 border-slate-700" placeholder="New Car Fund" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="type">Type</Label>
                <Select name="type" required defaultValue="custom">
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {GOAL_TYPES.map(type => (
                      <SelectItem key={type} value={type} className="capitalize">{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="targetAmount">Target Amount</Label>
                  <Input id="targetAmount" name="targetAmount" type="number" step="0.01" min="1" required className="bg-slate-800 border-slate-700" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="savedAmount">Already Saved</Label>
                  <Input id="savedAmount" name="savedAmount" type="number" step="0.01" min="0" defaultValue="0" className="bg-slate-800 border-slate-700" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="deadline">Target Date (Optional)</Label>
                <Input id="deadline" name="deadline" type="date" className="bg-slate-800 border-slate-700" />
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createMutation.isPending} className="bg-cyan-600 hover:bg-cyan-700">
                  {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Save Goal
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex justify-center p-12"><Loader2 className="h-8 w-8 animate-spin text-cyan-500" /></div>
      ) : goals?.length === 0 ? (
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <Trophy className="h-16 w-16 text-slate-700 mb-4" />
            <h3 className="text-xl font-medium text-white mb-2">No goals set</h3>
            <p className="text-slate-400 max-w-md">Setting financial goals gives your money purpose. Create a goal to start tracking your savings.</p>
            <Button className="mt-6 bg-slate-800 text-white hover:bg-slate-700" onClick={() => setIsAddOpen(true)}>
              Create your first goal
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {goals?.map((goal) => {
            const percentage = Math.min(100, Math.round((goal.savedAmount / goal.targetAmount) * 100));
            const isCompleted = percentage >= 100;

            return (
              <Card key={goal.id} className="bg-slate-900 border-slate-800" data-testid={`goal-card-${goal.id}`}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg text-white">{goal.name}</CardTitle>
                      <CardDescription className="text-slate-400 capitalize flex items-center gap-2">
                        {goal.type}
                        {goal.deadline && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700">
                            By {format(new Date(goal.deadline), 'MMM yyyy')}
                          </span>
                        )}
                      </CardDescription>
                    </div>
                    <div className="flex gap-1">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-slate-400 hover:text-white hover:bg-slate-800"
                        onClick={() => {
                          setSelectedGoal(goal);
                          setIsEditOpen(true);
                        }}
                      >
                        <Pencil className="h-3 w-3" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10"
                        onClick={() => {
                          if (confirm("Delete this goal?")) {
                            deleteMutation.mutate({ id: goal.id });
                          }
                        }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-end mb-2">
                    <div>
                      <span className="text-2xl font-bold text-white">${goal.savedAmount.toFixed(0)}</span>
                      <span className="text-slate-400 text-sm ml-1">/ ${goal.targetAmount.toFixed(0)}</span>
                    </div>
                    <span className={`text-sm font-medium ${isCompleted ? 'text-emerald-400' : 'text-cyan-400'}`}>
                      {percentage}%
                    </span>
                  </div>
                  <Progress 
                    value={percentage} 
                    className="h-2 bg-slate-800"
                    indicatorClassName={isCompleted ? "bg-emerald-500" : "bg-cyan-500"}
                  />
                  {isCompleted && (
                    <div className="mt-4 text-xs font-medium text-emerald-400 flex items-center justify-end">
                      <Trophy className="h-3 w-3 mr-1" /> Goal Reached!
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white">
          <DialogHeader>
            <DialogTitle>Edit Goal</DialogTitle>
          </DialogHeader>
          {selectedGoal && (
            <form onSubmit={handleEditSubmit} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Goal Name</Label>
                <Input id="edit-name" name="name" required defaultValue={selectedGoal.name} className="bg-slate-800 border-slate-700" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-type">Type</Label>
                <Select name="type" required defaultValue={selectedGoal.type}>
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {GOAL_TYPES.map(type => (
                      <SelectItem key={type} value={type} className="capitalize">{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-targetAmount">Target Amount</Label>
                  <Input id="edit-targetAmount" name="targetAmount" type="number" step="0.01" min="1" required defaultValue={selectedGoal.targetAmount} className="bg-slate-800 border-slate-700" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-savedAmount">Saved Amount</Label>
                  <Input id="edit-savedAmount" name="savedAmount" type="number" step="0.01" min="0" required defaultValue={selectedGoal.savedAmount} className="bg-slate-800 border-slate-700" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-deadline">Target Date (Optional)</Label>
                <Input id="edit-deadline" name="deadline" type="date" defaultValue={selectedGoal.deadline ? selectedGoal.deadline.split('T')[0] : ''} className="bg-slate-800 border-slate-700" />
              </div>
              <DialogFooter>
                <Button type="submit" disabled={updateMutation.isPending} className="bg-cyan-600 hover:bg-cyan-700">
                  {updateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Update Goal
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
