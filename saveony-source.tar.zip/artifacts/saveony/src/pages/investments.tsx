import { useState } from "react";
import { useListInvestments, useCreateInvestment, useUpdateInvestment, useDeleteInvestment, getListInvestmentsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Pencil, Trash2, Loader2, LineChart, TrendingUp, TrendingDown } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

const ASSET_TYPES = ["stocks", "mutual_funds", "etf", "sip", "bonds", "gold", "crypto"];

export function Investments() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [selectedInv, setSelectedInv] = useState<any>(null);

  const { data: investments, isLoading } = useListInvestments();

  const createMutation = useCreateInvestment({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListInvestmentsQueryKey() });
        setIsAddOpen(false);
        toast({ title: "Investment added successfully" });
      }
    }
  });

  const updateMutation = useUpdateInvestment({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListInvestmentsQueryKey() });
        setIsEditOpen(false);
        toast({ title: "Investment updated successfully" });
      }
    }
  });

  const deleteMutation = useDeleteInvestment({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListInvestmentsQueryKey() });
        toast({ title: "Investment deleted successfully" });
      }
    }
  });

  const handleAddSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createMutation.mutate({
      data: {
        name: formData.get("name") as string,
        assetType: formData.get("assetType") as string,
        quantity: Number(formData.get("quantity")),
        purchasePrice: Number(formData.get("purchasePrice")),
        currentPrice: Number(formData.get("currentPrice")),
        purchaseDate: formData.get("purchaseDate") as string,
      }
    });
  };

  const handleEditSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedInv) return;
    const formData = new FormData(e.currentTarget);
    updateMutation.mutate({
      id: selectedInv.id,
      data: {
        name: formData.get("name") as string,
        assetType: formData.get("assetType") as string,
        quantity: Number(formData.get("quantity")),
        currentPrice: Number(formData.get("currentPrice")),
      }
    });
  };

  const totalValue = investments?.reduce((acc, inv) => acc + (inv.quantity * inv.currentPrice), 0) || 0;
  const totalCost = investments?.reduce((acc, inv) => acc + (inv.quantity * inv.purchasePrice), 0) || 0;
  const totalProfit = totalValue - totalCost;
  const profitPercentage = totalCost > 0 ? (totalProfit / totalCost) * 100 : 0;

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">Investments</h1>
          <p className="text-slate-400 mt-1">Track your portfolio performance.</p>
        </div>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="bg-orange-600 hover:bg-orange-700 text-white" data-testid="button-add-investment">
              <Plus className="mr-2 h-4 w-4" /> Add Asset
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-900 border-slate-800 text-white">
            <DialogHeader>
              <DialogTitle>Add New Asset</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddSubmit} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="name">Asset Name / Ticker</Label>
                <Input id="name" name="name" required className="bg-slate-800 border-slate-700" placeholder="AAPL" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="assetType">Asset Type</Label>
                <Select name="assetType" required defaultValue="stocks">
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {ASSET_TYPES.map(type => (
                      <SelectItem key={type} value={type} className="capitalize">{type.replace('_', ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input id="quantity" name="quantity" type="number" step="any" min="0" required className="bg-slate-800 border-slate-700" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="purchaseDate">Purchase Date</Label>
                  <Input id="purchaseDate" name="purchaseDate" type="date" required defaultValue={new Date().toISOString().split('T')[0]} className="bg-slate-800 border-slate-700" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="purchasePrice">Purchase Price</Label>
                  <Input id="purchasePrice" name="purchasePrice" type="number" step="0.01" min="0" required className="bg-slate-800 border-slate-700" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="currentPrice">Current Price</Label>
                  <Input id="currentPrice" name="currentPrice" type="number" step="0.01" min="0" required className="bg-slate-800 border-slate-700" />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createMutation.isPending} className="bg-orange-600 hover:bg-orange-700">
                  {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Save Asset
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="pt-6">
            <p className="text-sm font-medium text-slate-400 mb-1">Total Portfolio Value</p>
            <div className="text-3xl font-bold text-white">${totalValue.toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="pt-6">
            <p className="text-sm font-medium text-slate-400 mb-1">Total Return</p>
            <div className={`text-3xl font-bold flex items-center ${totalProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {totalProfit >= 0 ? '+' : '-'}${Math.abs(totalProfit).toFixed(2)}
              {totalProfit >= 0 ? <TrendingUp className="ml-2 h-6 w-6" /> : <TrendingDown className="ml-2 h-6 w-6" />}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="pt-6">
            <p className="text-sm font-medium text-slate-400 mb-1">Return %</p>
            <div className={`text-3xl font-bold ${profitPercentage >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {profitPercentage >= 0 ? '+' : ''}{profitPercentage.toFixed(2)}%
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white">Your Assets</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center p-8"><Loader2 className="h-8 w-8 animate-spin text-orange-500" /></div>
          ) : investments?.length === 0 ? (
             <div className="text-center py-12 text-slate-400">
              <LineChart className="mx-auto h-12 w-12 text-slate-600 mb-3" />
              <h3 className="text-lg font-medium text-white mb-1">No investments yet</h3>
              <p>Add assets to track your portfolio performance.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-800 hover:bg-slate-800/50">
                    <TableHead className="text-slate-400">Asset</TableHead>
                    <TableHead className="text-slate-400">Type</TableHead>
                    <TableHead className="text-right text-slate-400">Holdings</TableHead>
                    <TableHead className="text-right text-slate-400">Avg Cost</TableHead>
                    <TableHead className="text-right text-slate-400">Current</TableHead>
                    <TableHead className="text-right text-slate-400">Return</TableHead>
                    <TableHead className="text-right text-slate-400">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {investments?.map((inv) => {
                    const cost = inv.quantity * inv.purchasePrice;
                    const value = inv.quantity * inv.currentPrice;
                    const profit = value - cost;
                    const profitPct = cost > 0 ? (profit / cost) * 100 : 0;
                    const isPositive = profit >= 0;

                    return (
                      <TableRow key={inv.id} className="border-slate-800 hover:bg-slate-800/50">
                        <TableCell className="text-white font-medium">{inv.name}</TableCell>
                        <TableCell>
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-800 text-slate-300 capitalize border border-slate-700">
                            {inv.assetType.replace('_', ' ')}
                          </span>
                        </TableCell>
                        <TableCell className="text-right text-slate-300">{inv.quantity}</TableCell>
                        <TableCell className="text-right text-slate-300">${inv.purchasePrice.toFixed(2)}</TableCell>
                        <TableCell className="text-right text-white font-medium">${inv.currentPrice.toFixed(2)}</TableCell>
                        <TableCell className={`text-right font-medium ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                          <div>{isPositive ? '+' : '-'}${Math.abs(profit).toFixed(2)}</div>
                          <div className="text-xs opacity-80">{isPositive ? '+' : ''}{profitPct.toFixed(2)}%</div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="text-slate-400 hover:text-white hover:bg-slate-800"
                              onClick={() => {
                                setSelectedInv(inv);
                                setIsEditOpen(true);
                              }}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="text-slate-400 hover:text-rose-400 hover:bg-rose-500/10"
                              onClick={() => {
                                if (confirm("Remove this asset?")) {
                                  deleteMutation.mutate({ id: inv.id });
                                }
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white">
          <DialogHeader>
            <DialogTitle>Update Asset</DialogTitle>
          </DialogHeader>
          {selectedInv && (
            <form onSubmit={handleEditSubmit} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Asset Name / Ticker</Label>
                <Input id="edit-name" name="name" required defaultValue={selectedInv.name} className="bg-slate-800 border-slate-700" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-assetType">Asset Type</Label>
                <Select name="assetType" required defaultValue={selectedInv.assetType}>
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {ASSET_TYPES.map(type => (
                      <SelectItem key={type} value={type} className="capitalize">{type.replace('_', ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-quantity">Total Quantity</Label>
                  <Input id="edit-quantity" name="quantity" type="number" step="any" min="0" required defaultValue={selectedInv.quantity} className="bg-slate-800 border-slate-700" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-currentPrice">Current Price</Label>
                  <Input id="edit-currentPrice" name="currentPrice" type="number" step="0.01" min="0" required defaultValue={selectedInv.currentPrice} className="bg-slate-800 border-slate-700" />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={updateMutation.isPending} className="bg-orange-600 hover:bg-orange-700">
                  {updateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Update Asset
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
