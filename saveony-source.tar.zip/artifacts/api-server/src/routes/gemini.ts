import { Router } from "express";
import { GoogleGenAI } from "@google/genai";
import { db, conversationsTable, messagesTable, expensesTable, incomeTable, investmentsTable, goalsTable } from "@workspace/db";
import { eq, and, desc, sql } from "drizzle-orm";
import { requireAuth } from "./auth";
import { logger } from "../lib/logger";

const router = Router();

function getGemini() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY not set");
  return new GoogleGenAI({ apiKey });
}

// GET /api/gemini/conversations
router.get("/conversations", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  try {
    const rows = await db.select().from(conversationsTable)
      .where(eq(conversationsTable.userId, user.id))
      .orderBy(desc(conversationsTable.updatedAt));
    res.json(rows.map(r => ({
      id: r.id,
      title: r.title,
      createdAt: r.createdAt.toISOString(),
      updatedAt: r.updatedAt.toISOString(),
    })));
  } catch (err) {
    logger.error({ err }, "Failed to list conversations");
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/gemini/conversations
router.post("/conversations", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const { title } = req.body;
  if (!title) return res.status(400).json({ error: "title is required" });
  try {
    const [row] = await db.insert(conversationsTable).values({
      userId: user.id,
      title,
    }).returning();
    res.status(201).json({ id: row.id, title: row.title, createdAt: row.createdAt.toISOString(), updatedAt: row.updatedAt.toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to create conversation");
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/gemini/conversations/:id
router.get("/conversations/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  try {
    const [conv] = await db.select().from(conversationsTable)
      .where(and(eq(conversationsTable.id, id), eq(conversationsTable.userId, user.id)));
    if (!conv) return res.status(404).json({ error: "Not found" });

    const msgs = await db.select().from(messagesTable)
      .where(eq(messagesTable.conversationId, id))
      .orderBy(messagesTable.createdAt);

    res.json({
      id: conv.id,
      title: conv.title,
      createdAt: conv.createdAt.toISOString(),
      updatedAt: conv.updatedAt.toISOString(),
      messages: msgs.map(m => ({
        id: m.id,
        conversationId: m.conversationId,
        role: m.role,
        content: m.content,
        createdAt: m.createdAt.toISOString(),
      })),
    });
  } catch (err) {
    logger.error({ err }, "Failed to get conversation");
    res.status(500).json({ error: "Internal server error" });
  }
});

// DELETE /api/gemini/conversations/:id
router.delete("/conversations/:id", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  try {
    await db.delete(messagesTable).where(eq(messagesTable.conversationId, id));
    await db.delete(conversationsTable).where(and(eq(conversationsTable.id, id), eq(conversationsTable.userId, user.id)));
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "Failed to delete conversation");
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/gemini/conversations/:id/messages
router.post("/conversations/:id/messages", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  const id = Number(req.params.id);
  const { content } = req.body;
  if (!content) return res.status(400).json({ error: "content is required" });

  try {
    const [conv] = await db.select().from(conversationsTable)
      .where(and(eq(conversationsTable.id, id), eq(conversationsTable.userId, user.id)));
    if (!conv) return res.status(404).json({ error: "Not found" });

    // Save user message
    await db.insert(messagesTable).values({ conversationId: id, role: "user", content });

    // Load history
    const history = await db.select().from(messagesTable)
      .where(eq(messagesTable.conversationId, id))
      .orderBy(messagesTable.createdAt);

    // Get basic user financial context
    const now = new Date();
    const monthStart = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`;
    const [{ totalExpenses }] = await db
      .select({ totalExpenses: sql<string>`coalesce(sum(${expensesTable.amount}), 0)` })
      .from(expensesTable)
      .where(and(eq(expensesTable.userId, user.id), sql`${expensesTable.date} >= ${monthStart}`));
    const [{ totalIncome }] = await db
      .select({ totalIncome: sql<string>`coalesce(sum(${incomeTable.amount}), 0)` })
      .from(incomeTable)
      .where(and(eq(incomeTable.userId, user.id), sql`${incomeTable.date} >= ${monthStart}`));
    const [{ investCount }] = await db
      .select({ investCount: sql<string>`count(*)` })
      .from(investmentsTable)
      .where(eq(investmentsTable.userId, user.id));
    const [{ goalCount }] = await db
      .select({ goalCount: sql<string>`count(*)` })
      .from(goalsTable)
      .where(eq(goalsTable.userId, user.id));

    const systemPrompt = `You are SAVEONY AI Financial Advisor — a precise, knowledgeable, and supportive personal finance assistant. 
You help users manage their money better with actionable, specific advice. Be concise but thorough. Use clear formatting.
Current user financial context (this month):
- Monthly Income: $${Number(totalIncome).toFixed(2)}
- Monthly Expenses: $${Number(totalExpenses).toFixed(2)}  
- Monthly Savings: $${Math.max(0, Number(totalIncome) - Number(totalExpenses)).toFixed(2)}
- Active Investments: ${investCount}
- Active Goals: ${goalCount}
Currency: ${user.currency}
Provide personalized advice based on this context. Do not use emojis.`;

    const gemini = getGemini();
    const chatHistory = history.slice(0, -1).map(m => ({
      role: m.role === "user" ? "user" as const : "model" as const,
      parts: [{ text: m.content }],
    }));

    const chat = gemini.chats.create({
      model: "gemini-2.5-flash",
      history: chatHistory,
      config: { systemInstruction: systemPrompt, maxOutputTokens: 8192 },
    });

    const response = await chat.sendMessage({ message: content });
    const replyText = response.text ?? "I was unable to generate a response. Please try again.";

    const [savedReply] = await db.insert(messagesTable).values({
      conversationId: id,
      role: "assistant",
      content: replyText,
    }).returning();

    // Update conversation updatedAt
    await db.update(conversationsTable).set({ updatedAt: new Date() }).where(eq(conversationsTable.id, id));

    res.json({
      id: savedReply.id,
      conversationId: savedReply.conversationId,
      role: savedReply.role,
      content: savedReply.content,
      createdAt: savedReply.createdAt.toISOString(),
    });
  } catch (err) {
    logger.error({ err }, "Failed to send message");
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/gemini/insights
router.get("/insights", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  try {
    const now = new Date();
    const monthStart = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`;

    const [{ totalExpenses }] = await db
      .select({ totalExpenses: sql<string>`coalesce(sum(${expensesTable.amount}), 0)` })
      .from(expensesTable)
      .where(and(eq(expensesTable.userId, user.id), sql`${expensesTable.date} >= ${monthStart}`));

    const [{ totalIncome }] = await db
      .select({ totalIncome: sql<string>`coalesce(sum(${incomeTable.amount}), 0)` })
      .from(incomeTable)
      .where(and(eq(incomeTable.userId, user.id), sql`${incomeTable.date} >= ${monthStart}`));

    const expCats = await db
      .select({ category: expensesTable.category, total: sql<string>`sum(${expensesTable.amount})` })
      .from(expensesTable)
      .where(and(eq(expensesTable.userId, user.id), sql`${expensesTable.date} >= ${monthStart}`))
      .groupBy(expensesTable.category);

    const monthlyIncome = Number(totalIncome);
    const monthlyExpenses = Number(totalExpenses);
    const savings = Math.max(0, monthlyIncome - monthlyExpenses);
    const savingsRate = monthlyIncome > 0 ? (savings / monthlyIncome) * 100 : 0;
    const topCategory = expCats.sort((a, b) => Number(b.total) - Number(a.total))[0];

    const gemini = getGemini();
    const prompt = `Analyze this user's financial data and provide 4 concise, actionable insights as a JSON array of strings. No emojis.
Monthly Income: $${monthlyIncome.toFixed(2)}
Monthly Expenses: $${monthlyExpenses.toFixed(2)}
Monthly Savings: $${savings.toFixed(2)} (${savingsRate.toFixed(1)}% savings rate)
Top expense category: ${topCategory?.category ?? "none"} ($${Number(topCategory?.total ?? 0).toFixed(2)})
Return ONLY valid JSON: {"insights": ["...", "...", "...", "..."], "spendingAlert": "..." or null, "savingsTip": "...", "investmentNote": "..."}`;

    const response = await gemini.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: { maxOutputTokens: 8192 },
    });

    let parsed = { insights: [], spendingAlert: null, savingsTip: null, investmentNote: null };
    try {
      const text = response.text ?? "{}";
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) parsed = JSON.parse(jsonMatch[0]);
    } catch {
      parsed.insights = [
        `Your savings rate is ${savingsRate.toFixed(1)}% this month.`,
        `Top spending category: ${topCategory?.category ?? "none"}.`,
        "Track your expenses daily to stay on budget.",
        "Consider setting up automatic savings transfers.",
      ] as any;
    }

    res.json({ ...parsed, generatedAt: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, "Failed to get insights");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
