import {
  db,
  expensesTable,
  incomeTable,
  budgetsTable,
  goalsTable,
  investmentsTable,
} from "@workspace/db";
import { logger } from "./logger";

function dateStr(daysAgo: number): string {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().slice(0, 10);
}

function monthStr(monthsAgo: number): string {
  const d = new Date();
  d.setDate(1);
  d.setMonth(d.getMonth() - monthsAgo);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export async function seedDemoData(userId: number): Promise<void> {
  try {
    logger.info({ userId }, "Seeding demo data for new user");

    // ── EXPENSES (6 months, realistic variety) ──────────────────────────────
    await db.insert(expensesTable).values([
      // Current month
      { userId, category: "bills", amount: "1200.00", description: "Monthly Rent", date: dateStr(2), recurring: true },
      { userId, category: "bills", amount: "82.50", description: "Electricity Bill", date: dateStr(3), recurring: true },
      { userId, category: "bills", amount: "59.99", description: "Internet - Fiber Plan", date: dateStr(4), recurring: true },
      { userId, category: "bills", amount: "14.99", description: "Netflix Subscription", date: dateStr(5), recurring: true },
      { userId, category: "bills", amount: "9.99", description: "Spotify Premium", date: dateStr(5), recurring: true },
      { userId, category: "food", amount: "67.40", description: "Weekly Groceries", date: dateStr(1), recurring: false },
      { userId, category: "food", amount: "24.80", description: "Lunch - Thai Kitchen", date: dateStr(2), recurring: false },
      { userId, category: "food", amount: "78.20", description: "Weekly Groceries", date: dateStr(7), recurring: false },
      { userId, category: "food", amount: "18.50", description: "Coffee & Snacks", date: dateStr(8), recurring: false },
      { userId, category: "food", amount: "52.30", description: "Dinner with Friends", date: dateStr(10), recurring: false },
      { userId, category: "shopping", amount: "149.99", description: "Running Shoes", date: dateStr(4), recurring: false },
      { userId, category: "shopping", amount: "34.99", description: "Books - Programming", date: dateStr(9), recurring: false },
      { userId, category: "entertainment", amount: "45.00", description: "Concert Tickets", date: dateStr(6), recurring: false },
      { userId, category: "entertainment", amount: "28.00", description: "Cinema - IMAX", date: dateStr(11), recurring: false },
      { userId, category: "healthcare", amount: "120.00", description: "Dental Checkup", date: dateStr(12), recurring: false },
      { userId, category: "education", amount: "199.00", description: "Online Course - React Advanced", date: dateStr(3), recurring: false },

      // Month -1
      { userId, category: "bills", amount: "1200.00", description: "Monthly Rent", date: dateStr(32), recurring: true },
      { userId, category: "bills", amount: "91.20", description: "Electricity Bill", date: dateStr(33), recurring: true },
      { userId, category: "bills", amount: "59.99", description: "Internet - Fiber Plan", date: dateStr(34), recurring: true },
      { userId, category: "bills", amount: "14.99", description: "Netflix Subscription", date: dateStr(35), recurring: true },
      { userId, category: "bills", amount: "9.99", description: "Spotify Premium", date: dateStr(35), recurring: true },
      { userId, category: "food", amount: "72.10", description: "Weekly Groceries", date: dateStr(30), recurring: false },
      { userId, category: "food", amount: "32.40", description: "Brunch - Sunday Café", date: dateStr(31), recurring: false },
      { userId, category: "food", amount: "63.80", description: "Weekly Groceries", date: dateStr(37), recurring: false },
      { userId, category: "food", amount: "19.90", description: "Coffee & Snacks", date: dateStr(38), recurring: false },
      { userId, category: "shopping", amount: "299.00", description: "Mechanical Keyboard", date: dateStr(36), recurring: false },
      { userId, category: "shopping", amount: "89.99", description: "Clothing - H&M", date: dateStr(40), recurring: false },
      { userId, category: "entertainment", amount: "65.00", description: "Sports Event Tickets", date: dateStr(39), recurring: false },
      { userId, category: "healthcare", amount: "45.00", description: "Gym Membership", date: dateStr(33), recurring: true },
      { userId, category: "travel", amount: "320.00", description: "Weekend Trip - Hotel", date: dateStr(44), recurring: false },
      { userId, category: "travel", amount: "78.50", description: "Flight Tickets (local)", date: dateStr(44), recurring: false },

      // Month -2
      { userId, category: "bills", amount: "1200.00", description: "Monthly Rent", date: dateStr(62), recurring: true },
      { userId, category: "bills", amount: "76.80", description: "Electricity Bill", date: dateStr(63), recurring: true },
      { userId, category: "bills", amount: "59.99", description: "Internet - Fiber Plan", date: dateStr(64), recurring: true },
      { userId, category: "bills", amount: "14.99", description: "Netflix Subscription", date: dateStr(65), recurring: true },
      { userId, category: "bills", amount: "9.99", description: "Spotify Premium", date: dateStr(65), recurring: true },
      { userId, category: "food", amount: "68.40", description: "Weekly Groceries", date: dateStr(60), recurring: false },
      { userId, category: "food", amount: "41.20", description: "Team Lunch", date: dateStr(61), recurring: false },
      { userId, category: "food", amount: "75.60", description: "Weekly Groceries", date: dateStr(67), recurring: false },
      { userId, category: "shopping", amount: "55.00", description: "Home Supplies", date: dateStr(66), recurring: false },
      { userId, category: "entertainment", amount: "120.00", description: "Birthday Dinner", date: dateStr(68), recurring: false },
      { userId, category: "healthcare", amount: "45.00", description: "Gym Membership", date: dateStr(63), recurring: true },
      { userId, category: "healthcare", amount: "180.00", description: "Annual Health Checkup", date: dateStr(70), recurring: false },
      { userId, category: "education", amount: "49.00", description: "Udemy Course Bundle", date: dateStr(69), recurring: false },

      // Month -3
      { userId, category: "bills", amount: "1200.00", description: "Monthly Rent", date: dateStr(92), recurring: true },
      { userId, category: "bills", amount: "88.60", description: "Electricity Bill", date: dateStr(93), recurring: true },
      { userId, category: "bills", amount: "59.99", description: "Internet - Fiber Plan", date: dateStr(94), recurring: true },
      { userId, category: "bills", amount: "14.99", description: "Netflix Subscription", date: dateStr(95), recurring: true },
      { userId, category: "bills", amount: "9.99", description: "Spotify Premium", date: dateStr(95), recurring: true },
      { userId, category: "food", amount: "71.20", description: "Weekly Groceries", date: dateStr(90), recurring: false },
      { userId, category: "food", amount: "29.50", description: "Sushi Dinner", date: dateStr(91), recurring: false },
      { userId, category: "food", amount: "66.30", description: "Weekly Groceries", date: dateStr(97), recurring: false },
      { userId, category: "food", amount: "22.00", description: "Coffee & Snacks", date: dateStr(98), recurring: false },
      { userId, category: "shopping", amount: "499.00", description: "Winter Jacket", date: dateStr(96), recurring: false },
      { userId, category: "shopping", amount: "79.00", description: "Kitchen Gadgets", date: dateStr(100), recurring: false },
      { userId, category: "entertainment", amount: "55.00", description: "Board Game Night Supplies", date: dateStr(99), recurring: false },
      { userId, category: "healthcare", amount: "45.00", description: "Gym Membership", date: dateStr(93), recurring: true },
      { userId, category: "travel", amount: "850.00", description: "Holiday Trip - Airfare", date: dateStr(103), recurring: false },
      { userId, category: "travel", amount: "420.00", description: "Holiday Trip - Hotel 3N", date: dateStr(104), recurring: false },

      // Month -4
      { userId, category: "bills", amount: "1200.00", description: "Monthly Rent", date: dateStr(122), recurring: true },
      { userId, category: "bills", amount: "79.40", description: "Electricity Bill", date: dateStr(123), recurring: true },
      { userId, category: "bills", amount: "59.99", description: "Internet - Fiber Plan", date: dateStr(124), recurring: true },
      { userId, category: "bills", amount: "14.99", description: "Netflix Subscription", date: dateStr(125), recurring: true },
      { userId, category: "bills", amount: "9.99", description: "Spotify Premium", date: dateStr(125), recurring: true },
      { userId, category: "food", amount: "64.70", description: "Weekly Groceries", date: dateStr(120), recurring: false },
      { userId, category: "food", amount: "38.90", description: "Lunch with Colleagues", date: dateStr(121), recurring: false },
      { userId, category: "food", amount: "59.20", description: "Weekly Groceries", date: dateStr(127), recurring: false },
      { userId, category: "shopping", amount: "229.00", description: "Smart Watch Band & Case", date: dateStr(126), recurring: false },
      { userId, category: "entertainment", amount: "85.00", description: "Theme Park Entry", date: dateStr(128), recurring: false },
      { userId, category: "healthcare", amount: "45.00", description: "Gym Membership", date: dateStr(123), recurring: true },
      { userId, category: "healthcare", amount: "60.00", description: "Eye Test & Glasses", date: dateStr(130), recurring: false },
      { userId, category: "education", amount: "89.00", description: "Design Course - Figma", date: dateStr(129), recurring: false },

      // Month -5
      { userId, category: "bills", amount: "1200.00", description: "Monthly Rent", date: dateStr(152), recurring: true },
      { userId, category: "bills", amount: "84.20", description: "Electricity Bill", date: dateStr(153), recurring: true },
      { userId, category: "bills", amount: "59.99", description: "Internet - Fiber Plan", date: dateStr(154), recurring: true },
      { userId, category: "bills", amount: "14.99", description: "Netflix Subscription", date: dateStr(155), recurring: true },
      { userId, category: "bills", amount: "9.99", description: "Spotify Premium", date: dateStr(155), recurring: true },
      { userId, category: "food", amount: "69.80", description: "Weekly Groceries", date: dateStr(150), recurring: false },
      { userId, category: "food", amount: "27.40", description: "Street Food & Snacks", date: dateStr(151), recurring: false },
      { userId, category: "food", amount: "73.50", description: "Weekly Groceries", date: dateStr(157), recurring: false },
      { userId, category: "shopping", amount: "159.99", description: "Headphones", date: dateStr(156), recurring: false },
      { userId, category: "shopping", amount: "44.00", description: "Stationery & Notebooks", date: dateStr(160), recurring: false },
      { userId, category: "entertainment", amount: "35.00", description: "Cinema & Snacks", date: dateStr(158), recurring: false },
      { userId, category: "healthcare", amount: "45.00", description: "Gym Membership", date: dateStr(153), recurring: true },
      { userId, category: "travel", amount: "180.00", description: "Day Trip - Train + Lunch", date: dateStr(162), recurring: false },
    ]);

    // ── INCOME (6 months) ───────────────────────────────────────────────────
    await db.insert(incomeTable).values([
      // Current month
      { userId, source: "salary", amount: "5500.00", description: "Monthly Salary - TechCorp", date: dateStr(1), recurring: true },
      { userId, source: "freelance", amount: "1200.00", description: "Web Design Project - Client A", date: dateStr(8), recurring: false },

      // Month -1
      { userId, source: "salary", amount: "5500.00", description: "Monthly Salary - TechCorp", date: dateStr(31), recurring: true },
      { userId, source: "freelance", amount: "750.00", description: "Logo Design - Startup B", date: dateStr(38), recurring: false },
      { userId, source: "dividends", amount: "248.30", description: "Dividend Payout - ETF Portfolio", date: dateStr(42), recurring: false },

      // Month -2
      { userId, source: "salary", amount: "5500.00", description: "Monthly Salary - TechCorp", date: dateStr(61), recurring: true },
      { userId, source: "freelance", amount: "2100.00", description: "Full-stack App - Client C", date: dateStr(68), recurring: false },

      // Month -3
      { userId, source: "salary", amount: "5500.00", description: "Monthly Salary - TechCorp", date: dateStr(91), recurring: true },
      { userId, source: "freelance", amount: "900.00", description: "API Integration - Agency", date: dateStr(98), recurring: false },
      { userId, source: "dividends", amount: "195.80", description: "Dividend Payout - ETF Portfolio", date: dateStr(102), recurring: false },
      { userId, source: "other", amount: "500.00", description: "Referral Bonus", date: dateStr(105), recurring: false },

      // Month -4
      { userId, source: "salary", amount: "5500.00", description: "Monthly Salary - TechCorp", date: dateStr(121), recurring: true },
      { userId, source: "freelance", amount: "1500.00", description: "Mobile UI Redesign", date: dateStr(128), recurring: false },
      { userId, source: "dividends", amount: "221.50", description: "Dividend Payout - ETF Portfolio", date: dateStr(132), recurring: false },

      // Month -5
      { userId, source: "salary", amount: "5500.00", description: "Monthly Salary - TechCorp", date: dateStr(151), recurring: true },
      { userId, source: "freelance", amount: "650.00", description: "Landing Page - Client D", date: dateStr(158), recurring: false },
    ]);

    // ── BUDGETS (current + previous month) ─────────────────────────────────
    const curMonth = monthStr(0);
    const prevMonth = monthStr(1);

    await db.insert(budgetsTable).values([
      // Current month budgets
      { userId, category: "food", limitAmount: "800.00", spentAmount: "241.20", month: curMonth },
      { userId, category: "shopping", limitAmount: "500.00", spentAmount: "184.98", month: curMonth },
      { userId, category: "bills", limitAmount: "1500.00", spentAmount: "1386.96", month: curMonth },
      { userId, category: "entertainment", limitAmount: "300.00", spentAmount: "73.00", month: curMonth },
      { userId, category: "healthcare", limitAmount: "400.00", spentAmount: "120.00", month: curMonth },
      { userId, category: "travel", limitAmount: "600.00", spentAmount: "0.00", month: curMonth },
      { userId, category: "education", limitAmount: "300.00", spentAmount: "199.00", month: curMonth },
      // Previous month budgets
      { userId, category: "food", limitAmount: "800.00", spentAmount: "748.30", month: prevMonth },
      { userId, category: "shopping", limitAmount: "500.00", spentAmount: "388.99", month: prevMonth },
      { userId, category: "bills", limitAmount: "1500.00", spentAmount: "1376.16", month: prevMonth },
      { userId, category: "entertainment", limitAmount: "300.00", spentAmount: "65.00", month: prevMonth },
      { userId, category: "healthcare", limitAmount: "400.00", spentAmount: "45.00", month: prevMonth },
      { userId, category: "travel", limitAmount: "600.00", spentAmount: "398.50", month: prevMonth },
    ]);

    // ── SAVINGS GOALS ───────────────────────────────────────────────────────
    await db.insert(goalsTable).values([
      {
        userId,
        name: "Emergency Fund",
        type: "emergency",
        targetAmount: "15000.00",
        savedAmount: "9200.00",
        deadline: dateStr(-365),
      },
      {
        userId,
        name: "House Down Payment",
        type: "house",
        targetAmount: "60000.00",
        savedAmount: "18500.00",
        deadline: dateStr(-730),
      },
      {
        userId,
        name: "Europe Vacation",
        type: "vacation",
        targetAmount: "5000.00",
        savedAmount: "3800.00",
        deadline: dateStr(-180),
      },
      {
        userId,
        name: "Retirement Fund",
        type: "retirement",
        targetAmount: "500000.00",
        savedAmount: "62000.00",
        deadline: null,
      },
      {
        userId,
        name: "New MacBook Pro",
        type: "other",
        targetAmount: "3500.00",
        savedAmount: "3500.00",
        deadline: dateStr(-30),
      },
    ]);

    // ── INVESTMENTS ─────────────────────────────────────────────────────────
    await db.insert(investmentsTable).values([
      {
        userId,
        name: "Apple Inc. (AAPL)",
        assetType: "stocks",
        purchasePrice: "152.40",
        currentPrice: "198.50",
        quantity: "15",
        purchaseDate: dateStr(365),
      },
      {
        userId,
        name: "NVIDIA Corp (NVDA)",
        assetType: "stocks",
        purchasePrice: "218.00",
        currentPrice: "875.40",
        quantity: "8",
        purchaseDate: dateStr(480),
      },
      {
        userId,
        name: "Vanguard S&P 500 ETF (VOO)",
        assetType: "etf",
        purchasePrice: "380.00",
        currentPrice: "510.20",
        quantity: "12",
        purchaseDate: dateStr(540),
      },
      {
        userId,
        name: "Bitcoin (BTC)",
        assetType: "crypto",
        purchasePrice: "28500.00",
        currentPrice: "67400.00",
        quantity: "0.35",
        purchaseDate: dateStr(600),
      },
      {
        userId,
        name: "Ethereum (ETH)",
        assetType: "crypto",
        purchasePrice: "1620.00",
        currentPrice: "3480.00",
        quantity: "2.5",
        purchaseDate: dateStr(420),
      },
      {
        userId,
        name: "iShares Global Clean Energy ETF",
        assetType: "etf",
        purchasePrice: "22.50",
        currentPrice: "19.80",
        quantity: "100",
        purchaseDate: dateStr(300),
      },
    ]);

    logger.info({ userId }, "Demo data seeded successfully");
  } catch (err) {
    logger.error({ err }, "Failed to seed demo data");
  }
}
