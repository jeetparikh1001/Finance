import { useState, useRef, useEffect } from "react";
import { useGetFinancialInsights, useListGeminiConversations, useCreateGeminiConversation, useSendGeminiMessage, useGetGeminiConversation, getListGeminiConversationsQueryKey, getGetGeminiConversationQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, MessageSquare, Send, Bot, User, Sparkles, Plus } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";

export function Advisor() {
  const queryClient = useQueryClient();
  const [input, setInput] = useState("");
  const [activeConvId, setActiveConvId] = useState<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: insights, isLoading: insightsLoading } = useGetFinancialInsights();
  const { data: conversations, isLoading: convsLoading } = useListGeminiConversations();
  
  const { data: activeConversation, isLoading: activeConvLoading } = useGetGeminiConversation(
    activeConvId as number,
    { query: { enabled: !!activeConvId, queryKey: getGetGeminiConversationQueryKey(activeConvId as number) } }
  );

  const createConvMutation = useCreateGeminiConversation({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
        setActiveConvId(data.id);
      }
    }
  });

  const sendMessageMutation = useSendGeminiMessage({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetGeminiConversationQueryKey(activeConvId!) });
      }
    }
  });

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [activeConversation?.messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    if (!activeConvId) {
      createConvMutation.mutate({ data: { title: input.substring(0, 30) + "..." } }, {
        onSuccess: (data) => {
          sendMessageMutation.mutate({ id: data.id, data: { content: input } });
          setInput("");
        }
      });
    } else {
      sendMessageMutation.mutate({ id: activeConvId, data: { content: input } });
      setInput("");
    }
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col animate-in fade-in duration-500">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white flex items-center gap-2">
          <Sparkles className="h-8 w-8 text-violet-500" />
          AI Financial Advisor
        </h1>
        <p className="text-slate-400 mt-1">Get personalized insights and ask questions about your finances.</p>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-6 min-h-0">
        {/* Sidebar: Insights & History */}
        <div className="col-span-1 flex flex-col gap-4 overflow-y-auto">
          <Card className="bg-slate-900 border-slate-800 shrink-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-300 uppercase tracking-wider">Smart Insights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {insightsLoading ? (
                <Loader2 className="h-5 w-5 animate-spin text-slate-500 mx-auto" />
              ) : insights ? (
                <>
                  {insights.spendingAlert && (
                    <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-lg text-sm text-rose-200">
                      {insights.spendingAlert}
                    </div>
                  )}
                  {insights.savingsTip && (
                    <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-sm text-emerald-200">
                      {insights.savingsTip}
                    </div>
                  )}
                  {insights.insights.slice(0, 2).map((ins, i) => (
                    <div key={i} className="p-3 bg-slate-800 rounded-lg text-sm text-slate-300">
                      {ins}
                    </div>
                  ))}
                </>
              ) : (
                <div className="text-sm text-slate-500">Add more financial data to get insights.</div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-slate-900 border-slate-800 flex-1 flex flex-col min-h-[200px]">
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <CardTitle className="text-sm font-medium text-slate-300 uppercase tracking-wider">Conversations</CardTitle>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-6 w-6 text-slate-400 hover:text-white"
                onClick={() => setActiveConvId(null)}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto space-y-1">
              {convsLoading ? (
                <Loader2 className="h-5 w-5 animate-spin text-slate-500 mx-auto" />
              ) : conversations?.map(conv => (
                <button
                  key={conv.id}
                  onClick={() => setActiveConvId(conv.id)}
                  className={`w-full text-left px-3 py-2 text-sm rounded-md truncate transition-colors ${
                    activeConvId === conv.id ? 'bg-violet-600/20 text-violet-300 font-medium' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  <MessageSquare className="inline-block h-3 w-3 mr-2 opacity-70" />
                  {conv.title}
                </button>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Chat Area */}
        <Card className="col-span-1 lg:col-span-3 bg-slate-900 border-slate-800 flex flex-col h-full">
          <CardHeader className="border-b border-slate-800 py-4">
            <CardTitle className="text-white text-lg">
              {activeConvId ? activeConversation?.title || "Loading..." : "New Conversation"}
            </CardTitle>
          </CardHeader>
          
          <CardContent className="flex-1 flex flex-col p-0 overflow-hidden">
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-6">
              {!activeConvId && (
                <div className="h-full flex flex-col items-center justify-center text-slate-500 p-8 text-center">
                  <Bot className="h-12 w-12 text-slate-700 mb-4" />
                  <p className="text-lg text-slate-300 font-medium mb-2">How can I help you today?</p>
                  <p className="max-w-md text-sm">I analyze your spending, income, and goals. Ask me how to save more, where you're overspending, or investment strategies.</p>
                </div>
              )}

              {activeConvLoading && <div className="flex justify-center p-4"><Loader2 className="h-6 w-6 animate-spin text-violet-500" /></div>}
              
              {activeConversation?.messages.map((msg) => (
                <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                  <div className={`shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${
                    msg.role === 'user' ? 'bg-slate-700 text-white' : 'bg-violet-600 text-white'
                  }`}>
                    {msg.role === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                  </div>
                  <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm ${
                    msg.role === 'user' 
                      ? 'bg-slate-800 text-slate-100 rounded-tr-none' 
                      : 'bg-violet-600/10 text-slate-200 border border-violet-500/20 rounded-tl-none'
                  }`}>
                    <div className="whitespace-pre-wrap">{msg.content}</div>
                    <div className={`text-[10px] mt-2 opacity-50 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                      {format(new Date(msg.createdAt), 'h:mm a')}
                    </div>
                  </div>
                </div>
              ))}
              
              {sendMessageMutation.isPending && (
                <div className="flex gap-4">
                  <div className="shrink-0 h-8 w-8 rounded-full bg-violet-600 text-white flex items-center justify-center">
                    <Bot className="h-4 w-4" />
                  </div>
                  <div className="max-w-[80%] rounded-2xl px-4 py-3 bg-violet-600/10 text-slate-200 border border-violet-500/20 rounded-tl-none flex items-center gap-2">
                    <span className="h-2 w-2 bg-violet-400 rounded-full animate-bounce"></span>
                    <span className="h-2 w-2 bg-violet-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                    <span className="h-2 w-2 bg-violet-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-800 bg-slate-900">
              <form onSubmit={handleSend} className="flex gap-2 relative">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask about your finances..."
                  className="bg-slate-800 border-slate-700 text-white pr-12 focus-visible:ring-violet-500"
                  disabled={sendMessageMutation.isPending || createConvMutation.isPending}
                />
                <Button 
                  type="submit" 
                  size="icon" 
                  className="absolute right-1 top-1 h-8 w-8 bg-violet-600 hover:bg-violet-700 text-white"
                  disabled={!input.trim() || sendMessageMutation.isPending || createConvMutation.isPending}
                >
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
