import { useGetRecurringDetection } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, RefreshCw, TrendingDown, TrendingUp, CheckCircle2, AlertCircle, Calendar, DollarSign } from "lucide-react";
import { format } from "date-fns";

const CATEGORY_COLORS: Record<string, string> = {
  bills: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  food: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  shopping: "bg-pink-500/10 text-pink-400 border-pink-500/20",
  entertainment: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  healthcare: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  travel: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
  education: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  insurance: "bg-slate-500/10 text-slate-400 border-slate-500/20",
  other: "bg-slate-500/10 text-slate-400 border-slate-500/20",
  salary: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  freelance: "bg-violet-500/10 text-violet-400 border-violet-500/20",
  dividends: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  rental: "bg-teal-500/10 text-teal-400 border-teal-500/20",
};

function categoryColor(cat: string) {
  return CATEGORY_COLORS[cat] ?? CATEGORY_COLORS.other;
}

function formatAmt(n: number) {
  return n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
}

function ConfidenceBadge({ confidence }: { confidence: string }) {
  if (confidence === "confirmed") {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-400">
        <CheckCircle2 className="h-3 w-3" /> Confirmed
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-400">
      <AlertCircle className="h-3 w-3" /> Likely
    </span>
  );
}

interface RecurringItem {
  key: string;
  description: string;
  category: string;
  amount: number;
  type: "expense" | "income";
  monthsDetected: number;
  confidence: string;
  lastSeen: string;
  totalSpent: number;
}

function RecurringCard({ item }: { item: RecurringItem }) {
  const isExpense = item.type === "expense";
  return (
    <div className="flex items-center justify-between p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-colors group">
      <div className="flex items-center gap-4 min-w-0">
        <div className={`h-10 w-10 rounded-lg flex items-center justify-center flex-shrink-0 ${isExpense ? "bg-rose-500/10" : "bg-emerald-500/10"}`}>
          {isExpense ? (
            <TrendingDown className="h-5 w-5 text-rose-400" />
          ) : (
            <TrendingUp className="h-5 w-5 text-emerald-400" />
          )}
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium text-slate-100 truncate">{item.description}</p>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border capitalize ${categoryColor(item.category)}`}>
              {item.category}
            </span>
            <ConfidenceBadge confidence={item.confidence} />
            <span className="inline-flex items-center gap-1 text-xs text-slate-500">
              <Calendar className="h-3 w-3" />
              {item.monthsDetected} month{item.monthsDetected !== 1 ? "s" : ""} detected
            </span>
          </div>
        </div>
      </div>
      <div className="text-right flex-shrink-0 ml-4">
        <p className={`text-base font-semibold ${isExpense ? "text-rose-400" : "text-emerald-400"}`}>
          {isExpense ? "-" : "+"}{formatAmt(item.amount)}<span className="text-xs text-slate-500 font-normal">/mo</span>
        </p>
        <p className="text-xs text-slate-500 mt-0.5">
          Last: {format(new Date(item.lastSeen), "MMM d, yyyy")}
        </p>
      </div>
    </div>
  );
}

export function Recurring() {
  const { data, isLoading, isError } = useGetRecurringDetection();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-violet-400" />
      </div>
    );
  }

  if (isError || !data) {
    return (
      <div className="flex items-center justify-center h-64 text-slate-400">
        Failed to load recurring data.
      </div>
    );
  }

  const { recurringExpenses, recurringIncome, totalMonthlyRecurringCost, totalMonthlyRecurringIncome, detectedAt } = data;
  const netMonthly = totalMonthlyRecurringIncome - totalMonthlyRecurringCost;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <RefreshCw className="h-6 w-6 text-violet-400" />
            Recurring Transactions
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Auto-detected from 6 months of transaction history · Last scanned {format(new Date(detectedAt), "MMM d, yyyy 'at' h:mm a")}
          </p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Monthly Subscriptions</span>
              <div className="h-8 w-8 rounded-lg bg-rose-500/10 flex items-center justify-center">
                <TrendingDown className="h-4 w-4 text-rose-400" />
              </div>
            </div>
            <p className="text-2xl font-bold text-rose-400">{formatAmt(totalMonthlyRecurringCost)}</p>
            <p className="text-xs text-slate-500 mt-1">{recurringExpenses.length} recurring expenses</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Monthly Recurring Income</span>
              <div className="h-8 w-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-emerald-400" />
              </div>
            </div>
            <p className="text-2xl font-bold text-emerald-400">{formatAmt(totalMonthlyRecurringIncome)}</p>
            <p className="text-xs text-slate-500 mt-1">{recurringIncome.length} recurring income streams</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Net Recurring Monthly</span>
              <div className={`h-8 w-8 rounded-lg flex items-center justify-center ${netMonthly >= 0 ? "bg-emerald-500/10" : "bg-rose-500/10"}`}>
                <DollarSign className={`h-4 w-4 ${netMonthly >= 0 ? "text-emerald-400" : "text-rose-400"}`} />
              </div>
            </div>
            <p className={`text-2xl font-bold ${netMonthly >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
              {netMonthly >= 0 ? "+" : ""}{formatAmt(netMonthly)}
            </p>
            <p className="text-xs text-slate-500 mt-1">Income minus fixed costs</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Annual Committed Cost</span>
              <div className="h-8 w-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
                <Calendar className="h-4 w-4 text-amber-400" />
              </div>
            </div>
            <p className="text-2xl font-bold text-amber-400">{formatAmt(totalMonthlyRecurringCost * 12)}</p>
            <p className="text-xs text-slate-500 mt-1">Per year in subscriptions</p>
          </CardContent>
        </Card>
      </div>

      {/* Recurring Expenses */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <TrendingDown className="h-5 w-5 text-rose-400" />
            Recurring Expenses
          </CardTitle>
          <CardDescription className="text-slate-400">
            {recurringExpenses.length > 0
              ? `${recurringExpenses.filter(r => r.confidence === "confirmed").length} confirmed · ${recurringExpenses.filter(r => r.confidence === "likely").length} likely · Sorted by amount`
              : "No recurring expenses detected in the last 6 months"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {recurringExpenses.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <RefreshCw className="h-10 w-10 mx-auto mb-3 opacity-20" />
              <p>No recurring patterns found yet.</p>
              <p className="text-xs mt-1">Patterns are detected after 2+ months of similar transactions.</p>
            </div>
          ) : (
            recurringExpenses.map(item => <RecurringCard key={item.key} item={item} />)
          )}
        </CardContent>
      </Card>

      {/* Recurring Income */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-emerald-400" />
            Recurring Income
          </CardTitle>
          <CardDescription className="text-slate-400">
            {recurringIncome.length > 0
              ? `${recurringIncome.filter(r => r.confidence === "confirmed").length} confirmed · ${recurringIncome.filter(r => r.confidence === "likely").length} likely`
              : "No recurring income detected in the last 6 months"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {recurringIncome.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <TrendingUp className="h-10 w-10 mx-auto mb-3 opacity-20" />
              <p>No recurring income patterns found yet.</p>
            </div>
          ) : (
            recurringIncome.map(item => <RecurringCard key={item.key} item={item} />)
          )}
        </CardContent>
      </Card>

      {/* Detection Info */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/30 p-4 flex gap-3">
        <AlertCircle className="h-5 w-5 text-slate-500 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-slate-400">
          <span className="font-medium text-slate-300">How detection works: </span>
          Transactions with the same description and amount appearing in <strong className="text-slate-200">2 or more months</strong> are flagged as <span className="text-amber-400">Likely</span> recurring. Those detected in <strong className="text-slate-200">3 or more months</strong> are marked <span className="text-emerald-400">Confirmed</span>.
        </div>
      </div>
    </div>
  );
}
