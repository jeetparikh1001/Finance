import { Router, type IRouter } from "express";
import healthRouter from "./health";
import usersRouter from "./users";
import expensesRouter from "./expenses";
import incomeRouter from "./income";
import budgetsRouter from "./budgets";
import goalsRouter from "./goals";
import investmentsRouter from "./investments";
import transactionsRouter from "./transactions";
import analyticsRouter from "./analytics";
import geminiRouter from "./gemini";
import seedRouter from "./seed";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/users", usersRouter);
router.use("/expenses", expensesRouter);
router.use("/income", incomeRouter);
router.use("/budgets", budgetsRouter);
router.use("/goals", goalsRouter);
router.use("/investments", investmentsRouter);
router.use("/transactions", transactionsRouter);
router.use("/analytics", analyticsRouter);
router.use("/gemini", geminiRouter);
router.use("/seed", seedRouter);

export default router;
