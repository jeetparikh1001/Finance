import { Router } from "express";
import { db, expensesTable, incomeTable, budgetsTable, goalsTable, investmentsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "./auth";
import { seedDemoData } from "../lib/seedDemoData";
import { logger } from "../lib/logger";

const router = Router();

// POST /api/seed — re-seed demo data for authenticated user (clears existing first)
router.post("/", requireAuth, async (req: any, res) => {
  const user = req.dbUser;
  try {
    await db.delete(expensesTable).where(eq(expensesTable.userId, user.id));
    await db.delete(incomeTable).where(eq(incomeTable.userId, user.id));
    await db.delete(budgetsTable).where(eq(budgetsTable.userId, user.id));
    await db.delete(goalsTable).where(eq(goalsTable.userId, user.id));
    await db.delete(investmentsTable).where(eq(investmentsTable.userId, user.id));
    await seedDemoData(user.id);
    res.json({ ok: true, message: "Demo data seeded successfully" });
  } catch (err) {
    logger.error({ err }, "Failed to re-seed");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
