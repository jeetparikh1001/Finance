import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "../lib/logger";
import { seedDemoData } from "../lib/seedDemoData";

const router = Router();

// Middleware to require auth and JIT-provision a user row
export const requireAuth = async (req: any, res: any, next: any) => {
  const auth = getAuth(req);
  const clerkId = auth?.userId;
  if (!clerkId) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  try {
    let [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
    if (!user) {
      // JIT provision using upsert to handle race conditions
      const emailAddress = (auth as any)?.sessionClaims?.email as string | undefined;
      const fullName = (auth as any)?.sessionClaims?.fullName as string | undefined;
      const inserted = await db.insert(usersTable).values({
        clerkId,
        name: fullName ?? "User",
        email: emailAddress ?? "",
        currency: "USD",
        language: "en",
      }).onConflictDoNothing().returning();
      if (inserted.length > 0) {
        user = inserted[0];
        // Seed demo data for brand-new users (non-blocking)
        seedDemoData(user.id).catch(err => logger.error({ err }, "seedDemoData failed"));
      } else {
        // Another request already inserted — fetch the row
        [user] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
      }
    }
    req.dbUser = user;
    next();
  } catch (err) {
    logger.error({ err }, "Failed to load/provision user");
    res.status(500).json({ error: "Internal server error" });
  }
};

export default router;
