import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useClerk, useUser } from "@clerk/react";
import {
  LayoutDashboard,
  Wallet,
  ArrowDownToLine,
  Target,
  LineChart,
  History,
  PieChart,
  MessageSquare,
  Settings,
  LogOut,
  Menu,
  RefreshCw,
  TrendingUp
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface LayoutProps {
  children: ReactNode;
}

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", href: "/dashboard" },
  { icon: Wallet, label: "Expenses", href: "/expenses" },
  { icon: ArrowDownToLine, label: "Income", href: "/income" },
  { icon: Target, label: "Budgets", href: "/budgets" },
  { icon: TrendingUp, label: "Goals", href: "/goals" },
  { icon: LineChart, label: "Investments", href: "/investments" },
  { icon: History, label: "Transactions", href: "/transactions" },
  { icon: RefreshCw, label: "Recurring", href: "/recurring" },
  { icon: PieChart, label: "Analytics", href: "/analytics" },
  { icon: MessageSquare, label: "AI Advisor", href: "/advisor" },
  { icon: Settings, label: "Settings", href: "/settings" },
];

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { signOut } = useClerk();
  const { user } = useUser();
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-slate-950 text-slate-300 border-r border-slate-800">
      <div className="p-6 flex items-center gap-3 border-b border-slate-800">
        <img src={`${basePath}/logo.svg`} alt="SAVEONY" className="h-8 w-8" />
        <span className="font-bold text-xl text-white tracking-tight">SAVEONY</span>
      </div>

      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors cursor-pointer ${
                  isActive
                    ? "bg-violet-600/10 text-violet-400 font-medium"
                    : "hover:bg-slate-900 hover:text-slate-100"
                }`}
                data-testid={`nav-${item.label.toLowerCase().replace(" ", "-")}`}
              >
                <item.icon className="h-5 w-5" />
                <span>{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-3 mb-4 px-2">
          <div className="h-10 w-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 font-bold overflow-hidden">
            {user?.imageUrl ? (
              <img src={user.imageUrl} alt={user.fullName || "User"} />
            ) : (
              user?.firstName?.charAt(0) || "U"
            )}
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-medium text-slate-200">
              {user?.fullName || "User"}
            </span>
            <span className="text-xs text-slate-500 truncate w-32">
              {user?.primaryEmailAddress?.emailAddress}
            </span>
          </div>
        </div>
        <Button
          variant="ghost"
          className="w-full justify-start text-slate-400 hover:text-white hover:bg-slate-900"
          onClick={() => signOut({ redirectUrl: basePath || "/" })}
          data-testid="button-logout"
        >
          <LogOut className="mr-2 h-4 w-4" />
          Log out
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen w-full bg-slate-950 overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-64 flex-shrink-0">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar & Header */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="md:hidden flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2">
            <img src={`${basePath}/logo.svg`} alt="SAVEONY" className="h-8 w-8" />
            <span className="font-bold text-xl text-white tracking-tight">SAVEONY</span>
          </div>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="text-slate-300" data-testid="button-mobile-menu">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-64 bg-slate-950 border-r-slate-800">
              <SidebarContent />
            </SheetContent>
          </Sheet>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8 bg-slate-950 text-slate-50 relative">
          <div className="max-w-7xl mx-auto h-full">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
